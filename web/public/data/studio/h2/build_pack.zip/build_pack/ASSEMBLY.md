# Assembly notes: Pipe coupling tightening

Product mode: not part of the pre-registered experiment. Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: **Two-tool head: Two-finger parallel + Two-finger linkage** (multi head), setup id `48274cb2290cdf2e`.

## Parts

* Tool 0: Two-finger parallel gripper, fin-ray pads (rigid fidelity).
* Tool 1: Two-finger linkage gripper of a cobot arm (rigid fidelity).

## Mounting

Print `bracket.stl` and bolt its hub face to the wrist flange. The bracket frame: origin at the centre of the flange face, z toward the wrist, x the axis the heads are tilted about.
* Head 0 (Two-finger parallel gripper, fin-ray pads): tilted -60 deg about the bracket's x axis, mount plane 70 mm from the wrist centre, 0 deg spin.
* Head 1 (Two-finger linkage gripper of a cobot arm): tilted 60 deg about the bracket's x axis, mount plane 70 mm from the wrist centre, 0 deg spin.
* Hub 10 mm, arms 24 mm across, adapters 8 mm.
* To use head k the wrist tilts the whole bracket by minus that head's angle, so the head points straight down on the roll axis; each switch costs 1.5 s [assumed].

## The task on this setup

| Step | Primitive | Object | Tool | Success |
|---|---|---|---|---|
| insert_coupling | insert | pipe_coupling | 0: Two-finger parallel gripper, fin-ray pads | 100% |
| tighten_coupling | twist | pipe_coupling | 1: Two-finger linkage gripper of a cobot arm | 100% |

Full-task completion 100% over 8 runs; median cycle 33.9 s including changes.

## Before you build

* Check every [assumed] value (bolt pattern, changer, bracket material) against your arm and tools.
* The simulation's wrist floats: it has no arm reach or arm collision model. Check reach and clearance on your arm.
* Run the task slowly on hardware first; the controllers are scripted and open-loop on placement.

## Files

* `ASSEMBLY.md`
* `CREDITS.txt`
* `README.txt`
* `bom.csv`
* `bracket.stl`
* `certificate.html`
* `licences/tool0_LICENSE.txt`
* `licences/tool1_LICENSE.txt`
* `manifest.json`
* `mjcf/meshes/tool0_06f366e008fc.stl`
* `mjcf/meshes/tool0_09e7a73e0d2e.stl`
* `mjcf/meshes/tool0_3c7632c7898b.stl`
* `mjcf/meshes/tool0_40ac89a5f09d.stl`
* `mjcf/meshes/tool0_81afb36d64fd.stl`
* `mjcf/meshes/tool0_84dea871450b.stl`
* `mjcf/meshes/tool1_8d7077d007c5.stl`
* `mjcf/meshes/tool1_8d9a1c8a1ef0.stl`
* `mjcf/meshes/tool1_924096430926.stl`
* `mjcf/meshes/tool1_a9f884861a3c.stl`
* `mjcf/meshes/tool1_d03a740e3af6.stl`
* `mjcf/setup_tool0.xml`
* `mjcf/setup_tool1.xml`
