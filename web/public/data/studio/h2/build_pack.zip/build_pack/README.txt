Build pack: Pipe coupling tightening

Product mode: not part of the pre-registered experiment
Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: Two-tool head: Two-finger parallel + Two-finger linkage (multi_head).
This is the Studio's recommendation for the task.
Task id: 33599e99ac277cf20e73d6acd349b9422330a255b3fe5ea48c6442a26c3decd6
Setup id: 48274cb2290cdf2e9ec0ba57d02a4a3d10e580eecbd471cfa4a455f4a327b7a0

Contents (manifest.json lists every file with its sha256, licence and source):
  ASSEMBLY.md
  CREDITS.txt
  README.txt
  bom.csv
  bracket.stl
  certificate.html
  licences/tool0_LICENSE.txt
  licences/tool1_LICENSE.txt
  manifest.json
  mjcf/meshes/tool0_06f366e008fc.stl
  mjcf/meshes/tool0_09e7a73e0d2e.stl
  mjcf/meshes/tool0_3c7632c7898b.stl
  mjcf/meshes/tool0_40ac89a5f09d.stl
  mjcf/meshes/tool0_81afb36d64fd.stl
  mjcf/meshes/tool0_84dea871450b.stl
  mjcf/meshes/tool1_8d7077d007c5.stl
  mjcf/meshes/tool1_8d9a1c8a1ef0.stl
  mjcf/meshes/tool1_924096430926.stl
  mjcf/meshes/tool1_a9f884861a3c.stl
  mjcf/meshes/tool1_d03a740e3af6.stl
  mjcf/setup_tool0.xml
  mjcf/setup_tool1.xml

STEP files are not provided: no CAD kernel is installed where packs are made. The STL files
are in millimetres; the MJCF folder loads in MuJoCo as is (mjcf/setup_tool<k>.xml).

Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.
