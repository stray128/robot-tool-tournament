Build pack: Solar panel installation

Product mode: not part of the pre-registered experiment
Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: Tool change: Vacuum area frame > Suction cup > Nut runner (tool_change).
This is the Studio's recommendation for the task.
Task id: cfd24f6d1ed0eb6b47202ff99d6aacb9cbc029e0960a0e30d16370f63c5adbcd
Setup id: 808f2a6999b71ad1fc884d2910cf48611ee70f759622afc2f5f0e8515912f7fd

Contents (manifest.json lists every file with its sha256, licence and source):
  ASSEMBLY.md
  CREDITS.txt
  README.txt
  bom.csv
  cad/tool0_reference.stl
  cad/tool1_reference.stl
  cad/tool2_reference.stl
  certificate.html
  changer_plate_tool0.stl
  changer_plate_tool1.stl
  changer_plate_tool2.stl
  manifest.json
  mjcf/setup_tool0.xml
  mjcf/setup_tool1.xml
  mjcf/setup_tool2.xml

STEP files are not provided: no CAD kernel is installed where packs are made. The STL files
are in millimetres; the MJCF folder loads in MuJoCo as is (mjcf/setup_tool<k>.xml).

Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.
