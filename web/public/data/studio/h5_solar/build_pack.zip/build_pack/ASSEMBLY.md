# Assembly notes: Solar panel installation

Product mode: not part of the pre-registered experiment. Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: **Tool change: Vacuum area frame > Suction cup > Nut runner** (tool change), setup id `808f2a6999b71ad1`.

## Parts

* Tool 0: Vacuum area frame, 2 x 3 cups, 600 mm (approximation fidelity).
* Tool 1: Suction cup, 10 mm bellows (approximation fidelity).
* Tool 2: Nut runner, 13 mm hex socket (approximation fidelity).

## Mounting

Bolt the tool changer's master plate to the wrist flange. Print one changer plate per tool (`changer_plate_tool<k>.stl`) and bolt it between the changer's tool plate and the tool.
* Changer stack 52 mm, changeover 7.5 s [assumed].

## The task on this setup

| Step | Primitive | Object | Tool | Success |
|---|---|---|---|---|
| place_panel | suction | solar_panel | 0: Vacuum area frame, 2 x 3 cups, 600 mm | 88% |
| insert_clamp | insert | solar_panel | 1: Suction cup, 10 mm bellows | 88% |
| tighten_clamp | twist | solar_panel | 2: Nut runner, 13 mm hex socket | 88% |

Full-task completion 88% over 8 runs; median cycle 62.4 s including changes.

## Before you build

* Check every [assumed] value (bolt pattern, changer, bracket material) against your arm and tools.
* The simulation's wrist floats: it has no arm reach or arm collision model. Check reach and clearance on your arm.
* Run the task slowly on hardware first; the controllers are scripted and open-loop on placement.

## Files

* `ASSEMBLY.md`
* `CREDITS.txt`
* `README.txt`
* `bom.csv`
* `cad/tool0_reference.stl`
* `cad/tool1_reference.stl`
* `cad/tool2_reference.stl`
* `certificate.html`
* `changer_plate_tool0.stl`
* `changer_plate_tool1.stl`
* `changer_plate_tool2.stl`
* `manifest.json`
* `mjcf/setup_tool0.xml`
* `mjcf/setup_tool1.xml`
* `mjcf/setup_tool2.xml`
