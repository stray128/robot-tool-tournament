Build pack: Warehouse returns tote lid open/close

Product mode: not part of the pre-registered experiment
Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: Two-tool head: Soft arm + Suction cup (multi_head).
This is the Studio's recommendation for the task.
Task id: e4586f3612e11b0eb490349c52a109bec75f43fdb0bcf9f1d91127f9e01a4ad5
Setup id: 9d7829e0d8861c572779cefc3cfce3110b92c0150e87f45e6fa82785e7f26f3f

Contents (manifest.json lists every file with its sha256, licence and source):
  ASSEMBLY.md
  CREDITS.txt
  README.txt
  bom.csv
  bracket.stl
  cad/tool0_reference.stl
  cad/tool1_reference.stl
  certificate.html
  manifest.json
  mjcf/setup_tool0.xml
  mjcf/setup_tool1.xml

STEP files are not provided: no CAD kernel is installed where packs are made. The STL files
are in millimetres; the MJCF folder loads in MuJoCo as is (mjcf/setup_tool<k>.xml).

Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.
