Build pack: Floor tiling

Product mode: not part of the pre-registered experiment
Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: Two-tool head: Vacuum area frame + Tamper pad (multi_head).
This is the Studio's recommendation for the task.
Task id: f9553b22ce12fc141c274d5532f25c97083ff5cd41faa49fc1927d9487fbc5a3
Setup id: 4adcc3231c74df612f82b2dbaba5f6dda3ab6ce38843e5a56d3752960e8519b0

Contents (manifest.json lists every file with its sha256, licence and source):
  ASSEMBLY.md
  CREDITS.txt
  README.txt
  bom.csv
  bracket.stl
  cad/tool0_reference.stl
  cad/tool1_reference.stl
  certificate.html
  manifest.json
  mjcf/setup_tool0.xml
  mjcf/setup_tool1.xml

STEP files are not provided: no CAD kernel is installed where packs are made. The STL files
are in millimetres; the MJCF folder loads in MuJoCo as is (mjcf/setup_tool<k>.xml).

Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.
