# Assembly notes: Floor tiling

Product mode: not part of the pre-registered experiment. Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: **Two-tool head: Vacuum area frame + Tamper pad** (multi head), setup id `4adcc3231c74df61`.

## Parts

* Tool 0: Vacuum area frame, 2 x 2 cups, 300 mm (approximation fidelity).
* Tool 1: Tamper pad, 200 mm (approximation fidelity).

## Mounting

Print `bracket.stl` and bolt its hub face to the wrist flange. The bracket frame: origin at the centre of the flange face, z toward the wrist, x the axis the heads are tilted about.
* Head 0 (Vacuum area frame, 2 x 2 cups, 300 mm): tilted -60 deg about the bracket's x axis, mount plane 50 mm from the wrist centre, 0 deg spin.
* Head 1 (Tamper pad, 200 mm): tilted 60 deg about the bracket's x axis, mount plane 50 mm from the wrist centre, 0 deg spin.
* Hub 10 mm, arms 24 mm across, adapters 8 mm.
* To use head k the wrist tilts the whole bracket by minus that head's angle, so the head points straight down on the roll axis; each switch costs 1.5 s [assumed].

## The task on this setup

| Step | Primitive | Object | Tool | Success |
|---|---|---|---|---|
| lay_tile | grasp | floor_tile | 0: Vacuum area frame, 2 x 2 cups, 300 mm | 100% |
| tamp_tile | push | floor_tile | 1: Tamper pad, 200 mm | 100% |

Full-task completion 100% over 8 runs; median cycle 19.2 s including changes.

## Before you build

* Check every [assumed] value (bolt pattern, changer, bracket material) against your arm and tools.
* The simulation's wrist floats: it has no arm reach or arm collision model. Check reach and clearance on your arm.
* Run the task slowly on hardware first; the controllers are scripted and open-loop on placement.

## Files

* `ASSEMBLY.md`
* `CREDITS.txt`
* `README.txt`
* `bom.csv`
* `bracket.stl`
* `cad/tool0_reference.stl`
* `cad/tool1_reference.stl`
* `certificate.html`
* `manifest.json`
* `mjcf/setup_tool0.xml`
* `mjcf/setup_tool1.xml`
