Build pack: Warehouse returns tote packing

Product mode: not part of the pre-registered experiment
Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: Industrial servo parallel gripper, 110 mm stroke (single).
This is the Studio's recommendation for the task.
Task id: 351218d6c47d46bba1e14ecb4cf230c592618cbe28e9bf1d8be29cb88085e4f8
Setup id: d136ab4824c1bad26b5ac84b7a481c14bedee5790c495f0eb8c1c9369bb11a57

Contents (manifest.json lists every file with its sha256, licence and source):
  ASSEMBLY.md
  CREDITS.txt
  README.txt
  bom.csv
  certificate.html
  licences/tool0_LICENSE.txt
  manifest.json
  mjcf/setup_tool0.xml

STEP files are not provided: no CAD kernel is installed where packs are made. The STL files
are in millimetres; the MJCF folder loads in MuJoCo as is (mjcf/setup_tool<k>.xml).

Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.
