# Assembly notes: Warehouse returns tote packing

Product mode: not part of the pre-registered experiment. Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: **Industrial servo parallel gripper, 110 mm stroke** (single), setup id `d136ab4824c1bad2`.

## Parts

* Tool 0: Industrial servo parallel gripper, 110 mm stroke (rigid fidelity).

## Mounting

Bolt the tool directly to the wrist flange (63 mm, ISO 9409-1-50-4-M6 pattern [assumed]), as in the simulation: its mount plane is the flange face.

## The task on this setup

| Step | Primitive | Object | Tool | Success |
|---|---|---|---|---|
| open_lid | hook_pull | tote_lid | 0: Industrial servo parallel gripper, 110 mm stroke | 100% |
| pick_carton | grasp | carton | 0: Industrial servo parallel gripper, 110 mm stroke | 100% |
| pick_pack | grasp | pack | 0: Industrial servo parallel gripper, 110 mm stroke | 100% |
| close_lid | push | tote_lid | 0: Industrial servo parallel gripper, 110 mm stroke | 100% |

Full-task completion 100% over 8 runs; median cycle 78.2 s including changes.

## Before you build

* Check every [assumed] value (bolt pattern, changer, bracket material) against your arm and tools.
* The simulation's wrist floats: it has no arm reach or arm collision model. Check reach and clearance on your arm.
* Run the task slowly on hardware first; the controllers are scripted and open-loop on placement.

## Files

* `ASSEMBLY.md`
* `CREDITS.txt`
* `README.txt`
* `bom.csv`
* `certificate.html`
* `licences/tool0_LICENSE.txt`
* `manifest.json`
* `mjcf/setup_tool0.xml`
