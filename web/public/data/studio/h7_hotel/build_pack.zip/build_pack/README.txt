Build pack: Hotel delivery mock-up

Product mode: not part of the pre-registered experiment
Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: Two-tool head: Suction cup + Angular-jaw gripper of (multi_head).
This is the Studio's recommendation for the task.
Task id: 2a0bc4766d10e13a1e62cf0ea4443e4b25f527fd3c7552ed74352a751469d442
Setup id: 5f6656e247bdbdf47a8393404d31273e6f9bebff8f948f3b9f79848826be41aa

Contents (manifest.json lists every file with its sha256, licence and source):
  ASSEMBLY.md
  CREDITS.txt
  README.txt
  bom.csv
  bracket.stl
  cad/tool0_reference.stl
  certificate.html
  licences/tool1_LICENSE.txt
  manifest.json
  mjcf/meshes/tool1_36981788061f.stl
  mjcf/meshes/tool1_73a6f1648a70.stl
  mjcf/meshes/tool1_bd59cb6d1713.stl
  mjcf/meshes/tool1_e232d7924468.stl
  mjcf/meshes/tool1_ed74c664d906.stl
  mjcf/setup_tool0.xml
  mjcf/setup_tool1.xml

STEP files are not provided: no CAD kernel is installed where packs are made. The STL files
are in millimetres; the MJCF folder loads in MuJoCo as is (mjcf/setup_tool<k>.xml).

Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.
