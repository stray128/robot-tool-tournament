Build pack: Hotel delivery mock-up

Product mode: not part of the pre-registered experiment
Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: Tool change: Drawer-pull > Force-controlled > Suction (tool_change).
This is the Studio's recommendation for the task.
Task id: dc0ae4f82a5123cc7039f7ac2e35fe3b54399c63dd4443c5cc50cb24c33e3243
Setup id: e38465aad8735559314fe4beca2de13556c1bc614e0c13a4274a9bf2f046b6fc

Contents (manifest.json lists every file with its sha256, licence and source):
  ASSEMBLY.md
  CREDITS.txt
  README.txt
  bom.csv
  cad/tool2_reference.stl
  certificate.html
  changer_plate_tool0.stl
  changer_plate_tool1.stl
  changer_plate_tool2.stl
  licences/tool1_LICENSE.txt
  manifest.json
  mjcf/meshes/tool0_0d7972acc323.stl
  mjcf/meshes/tool0_20bc0847ded1.stl
  mjcf/meshes/tool0_211e85791563.stl
  mjcf/meshes/tool0_3af3ca58f57d.stl
  mjcf/meshes/tool0_46c19aa42b81.stl
  mjcf/meshes/tool0_54ed8f7695d6.stl
  mjcf/meshes/tool0_559a44c38492.stl
  mjcf/meshes/tool0_5854e4d4c85f.stl
  mjcf/meshes/tool0_7c1d6ed24f48.stl
  mjcf/meshes/tool0_7f2bb25a7247.stl
  mjcf/meshes/tool0_8788e6e30b26.stl
  mjcf/meshes/tool0_9cd5806865ae.stl
  mjcf/meshes/tool0_a5e8da967b2e.stl
  mjcf/meshes/tool0_eb1723b5e8d3.stl
  mjcf/meshes/tool0_f5df3b95608b.stl
  mjcf/meshes/tool0_f6206c96d7c7.stl
  mjcf/meshes/tool1_21f41404f0c6.stl
  mjcf/meshes/tool1_883c98ad0465.stl
  mjcf/meshes/tool1_e658e950bc54.stl
  mjcf/setup_tool0.xml
  mjcf/setup_tool1.xml
  mjcf/setup_tool2.xml

STEP files are not provided: no CAD kernel is installed where packs are made. The STL files
are in millimetres; the MJCF folder loads in MuJoCo as is (mjcf/setup_tool<k>.xml).

Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.
