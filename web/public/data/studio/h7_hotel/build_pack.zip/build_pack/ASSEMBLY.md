# Assembly notes: Hotel delivery mock-up

Product mode: not part of the pre-registered experiment. Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: **Tool change: Drawer-pull > Force-controlled > Suction** (tool change), setup id `e38465aad8735559`.

## Parts

* Tool 0: Drawer-pull hook tool (rigid fidelity).
* Tool 1: Force-controlled parallel gripper, 48 mm stroke (rigid fidelity).
* Tool 2: Suction cup, 25 mm bellows (approximation fidelity).

## Mounting

Bolt the tool changer's master plate to the wrist flange. Print one changer plate per tool (`changer_plate_tool<k>.stl`) and bolt it between the changer's tool plate and the tool.
* Changer stack 52 mm, changeover 7.5 s [assumed].

## The task on this setup

| Step | Primitive | Object | Tool | Success |
|---|---|---|---|---|
| press_button | push | call_button | 0: Drawer-pull hook tool | 100% |
| open_door | hook_pull | room_door | 1: Force-controlled parallel gripper, 48 mm stroke | 100% |
| place_parcel | grasp | parcel | 2: Suction cup, 25 mm bellows | 100% |

Full-task completion 100% over 8 runs; median cycle 63.8 s including changes.

## Before you build

* Check every [assumed] value (bolt pattern, changer, bracket material) against your arm and tools.
* The simulation's wrist floats: it has no arm reach or arm collision model. Check reach and clearance on your arm.
* Run the task slowly on hardware first; the controllers are scripted and open-loop on placement.

## Files

* `ASSEMBLY.md`
* `CREDITS.txt`
* `README.txt`
* `bom.csv`
* `cad/tool2_reference.stl`
* `certificate.html`
* `changer_plate_tool0.stl`
* `changer_plate_tool1.stl`
* `changer_plate_tool2.stl`
* `licences/tool1_LICENSE.txt`
* `manifest.json`
* `mjcf/meshes/tool0_0d7972acc323.stl`
* `mjcf/meshes/tool0_20bc0847ded1.stl`
* `mjcf/meshes/tool0_211e85791563.stl`
* `mjcf/meshes/tool0_3af3ca58f57d.stl`
* `mjcf/meshes/tool0_46c19aa42b81.stl`
* `mjcf/meshes/tool0_54ed8f7695d6.stl`
* `mjcf/meshes/tool0_559a44c38492.stl`
* `mjcf/meshes/tool0_5854e4d4c85f.stl`
* `mjcf/meshes/tool0_7c1d6ed24f48.stl`
* `mjcf/meshes/tool0_7f2bb25a7247.stl`
* `mjcf/meshes/tool0_8788e6e30b26.stl`
* `mjcf/meshes/tool0_9cd5806865ae.stl`
* `mjcf/meshes/tool0_a5e8da967b2e.stl`
* `mjcf/meshes/tool0_eb1723b5e8d3.stl`
* `mjcf/meshes/tool0_f5df3b95608b.stl`
* `mjcf/meshes/tool0_f6206c96d7c7.stl`
* `mjcf/meshes/tool1_21f41404f0c6.stl`
* `mjcf/meshes/tool1_883c98ad0465.stl`
* `mjcf/meshes/tool1_e658e950bc54.stl`
* `mjcf/setup_tool0.xml`
* `mjcf/setup_tool1.xml`
* `mjcf/setup_tool2.xml`
