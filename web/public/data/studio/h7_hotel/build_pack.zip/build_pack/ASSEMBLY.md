# Assembly notes: Hotel delivery mock-up

Product mode: not part of the pre-registered experiment. Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: **Two-tool head: Suction cup + Angular-jaw gripper of** (multi head), setup id `5f6656e247bdbdf4`.

## Parts

* Tool 0: Suction cup, 25 mm bellows (approximation fidelity).
* Tool 1: Angular-jaw gripper of an open hobby arm (rigid fidelity).

## Mounting

Print `bracket.stl` and bolt its hub face to the wrist flange. The bracket frame: origin at the centre of the flange face, z toward the wrist, x the axis the heads are tilted about.
* Head 0 (Suction cup, 25 mm bellows): tilted -30 deg about the bracket's x axis, mount plane 70 mm from the wrist centre, 0 deg spin.
* Head 1 (Angular-jaw gripper of an open hobby arm): tilted 30 deg about the bracket's x axis, mount plane 70 mm from the wrist centre, 0 deg spin.
* Hub 10 mm, arms 24 mm across, adapters 8 mm.
* To use head k the wrist tilts the whole bracket by minus that head's angle, so the head points straight down on the roll axis; each switch costs 1.5 s [assumed].

## The task on this setup

| Step | Primitive | Object | Tool | Success |
|---|---|---|---|---|
| press_button | push | call_button | 0: Suction cup, 25 mm bellows | 100% |
| open_door | hook_pull | room_door | 1: Angular-jaw gripper of an open hobby arm | 100% |
| place_parcel | grasp | parcel | 0: Suction cup, 25 mm bellows | 100% |

Full-task completion 100% over 8 runs; median cycle 51.4 s including changes.

## Before you build

* Check every [assumed] value (bolt pattern, changer, bracket material) against your arm and tools.
* The simulation's wrist floats: it has no arm reach or arm collision model. Check reach and clearance on your arm.
* Run the task slowly on hardware first; the controllers are scripted and open-loop on placement.

## Files

* `ASSEMBLY.md`
* `CREDITS.txt`
* `README.txt`
* `bom.csv`
* `bracket.stl`
* `cad/tool0_reference.stl`
* `certificate.html`
* `licences/tool1_LICENSE.txt`
* `manifest.json`
* `mjcf/meshes/tool1_36981788061f.stl`
* `mjcf/meshes/tool1_73a6f1648a70.stl`
* `mjcf/meshes/tool1_bd59cb6d1713.stl`
* `mjcf/meshes/tool1_e232d7924468.stl`
* `mjcf/meshes/tool1_ed74c664d906.stl`
* `mjcf/setup_tool0.xml`
* `mjcf/setup_tool1.xml`
