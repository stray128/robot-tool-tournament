# Assembly notes: Cabinet maintenance

Product mode: not part of the pre-registered experiment. Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: **Tool change: Two-finger > Force-controlled > Two-finger** (tool change), setup id `4a5ca67a8577219b`.

## Parts

* Tool 0: Two-finger adaptive linkage gripper, 85 mm (rigid fidelity).
* Tool 1: Force-controlled parallel gripper, 48 mm stroke (rigid fidelity).
* Tool 2: Two-finger parallel cobot hand, 80 mm (rigid fidelity).

## Mounting

Bolt the tool changer's master plate to the wrist flange. Print one changer plate per tool (`changer_plate_tool<k>.stl`) and bolt it between the changer's tool plate and the tool.
* Changer stack 25 mm, changeover 6 s [assumed].

## The task on this setup

| Step | Primitive | Object | Tool | Success |
|---|---|---|---|---|
| unlock_latch | twist | qt_latch | 0: Two-finger adaptive linkage gripper, 85 mm | 100% |
| open_door | hook_pull | cabinet_door | 1: Force-controlled parallel gripper, 48 mm stroke | 88% |
| open_valve | twist | service_valve | 2: Two-finger parallel cobot hand, 80 mm | 62% |
| plug_connector | insert | test_port | 1: Force-controlled parallel gripper, 48 mm stroke | 50% |

Full-task completion 50% over 8 runs; median cycle 71.7 s including changes.

## Before you build

* Check every [assumed] value (bolt pattern, changer, bracket material) against your arm and tools.
* The simulation's wrist floats: it has no arm reach or arm collision model. Check reach and clearance on your arm.
* Run the task slowly on hardware first; the controllers are scripted and open-loop on placement.

## Files

* `ASSEMBLY.md`
* `CREDITS.txt`
* `README.txt`
* `bom.csv`
* `certificate.html`
* `changer_plate_tool0.stl`
* `changer_plate_tool1.stl`
* `changer_plate_tool2.stl`
* `licences/tool0_LICENSE.txt`
* `licences/tool1_LICENSE.txt`
* `licences/tool2_LICENSE.txt`
* `manifest.json`
* `mjcf/meshes/tool0_3d49ad2f1e5f.stl`
* `mjcf/meshes/tool0_550554299ed7.stl`
* `mjcf/meshes/tool0_6639c2189c8b.stl`
* `mjcf/meshes/tool0_90a6b59d8b50.stl`
* `mjcf/meshes/tool0_ce995a164450.stl`
* `mjcf/meshes/tool0_ef7396ba3930.stl`
* `mjcf/meshes/tool1_21f41404f0c6.stl`
* `mjcf/meshes/tool1_883c98ad0465.stl`
* `mjcf/meshes/tool1_e658e950bc54.stl`
* `mjcf/meshes/tool2_26b3c0a30980.stl`
* `mjcf/meshes/tool2_2bad15dcee9d.stl`
* `mjcf/setup_tool0.xml`
* `mjcf/setup_tool1.xml`
* `mjcf/setup_tool2.xml`
