Build pack: Cabinet maintenance

Product mode: not part of the pre-registered experiment
Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.

Setup: Tool change: Two-finger > Force-controlled > Two-finger (tool_change).
This is the Studio's recommendation for the task.
Task id: 3297a111d7c61392e9a99a08d3a80a8e14c7046b80d277925ed3a78788ff651d
Setup id: 4a5ca67a8577219bf4f87501e90e8e532276f839b488a9b86dfc6a86a472700c

Contents (manifest.json lists every file with its sha256, licence and source):
  ASSEMBLY.md
  CREDITS.txt
  README.txt
  bom.csv
  certificate.html
  changer_plate_tool0.stl
  changer_plate_tool1.stl
  changer_plate_tool2.stl
  licences/tool0_LICENSE.txt
  licences/tool1_LICENSE.txt
  licences/tool2_LICENSE.txt
  manifest.json
  mjcf/meshes/tool0_3d49ad2f1e5f.stl
  mjcf/meshes/tool0_550554299ed7.stl
  mjcf/meshes/tool0_6639c2189c8b.stl
  mjcf/meshes/tool0_90a6b59d8b50.stl
  mjcf/meshes/tool0_ce995a164450.stl
  mjcf/meshes/tool0_ef7396ba3930.stl
  mjcf/meshes/tool1_21f41404f0c6.stl
  mjcf/meshes/tool1_883c98ad0465.stl
  mjcf/meshes/tool1_e658e950bc54.stl
  mjcf/meshes/tool2_26b3c0a30980.stl
  mjcf/meshes/tool2_2bad15dcee9d.stl
  mjcf/setup_tool0.xml
  mjcf/setup_tool1.xml
  mjcf/setup_tool2.xml

STEP files are not provided: no CAD kernel is installed where packs are made. The STL files
are in millimetres; the MJCF folder loads in MuJoCo as is (mjcf/setup_tool<k>.xml).

Simulated in MuJoCo and untested on hardware. A recommendation is a simulation ranking under the stated conditions, not a hardware guarantee.
