Fixture build pack for the Studio tests.
